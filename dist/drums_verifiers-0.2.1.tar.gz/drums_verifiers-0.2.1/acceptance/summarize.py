"""summarize.py RD: the acceptance verdict from the raw records (writes RD/summary.json, prints a short text form).

Per run: traces, valid / dropped / errored, rewards handed out, drop reasons, fork structure, and for every trace the
screenshots the model received (from prime-rl's own trace stream). Pass criteria are listed in acceptance.sh."""
import base64
import collections
import glob
import hashlib
import json
import os
import sys

RD = sys.argv[1]


def episodes_of(run_dir):
    """Every episode prime-rl recorded (ok, number of traces, first error), from the same stream."""
    import pyzstd
    out = []
    for f in sorted(glob.glob(os.path.join(run_dir, "out", "*", "monitors", "file", "traces", "stream", "*.jsonl.zst"))):
        for line in pyzstd.decompress(open(f, "rb").read()).decode().splitlines():
            if line.strip():
                ep = json.loads(line)
                out.append({"ok": ep.get("ok"), "traces": len(ep.get("traces", [])),
                            "error": ((ep.get("errors") or [{}])[0].get("message") or "")[:200] or None})
    return out


def traces_of(run_dir):
    """Every trace of the run from prime-rl's file monitor stream (zstd JSONL of episodes)."""
    import pyzstd
    out = []
    for f in sorted(glob.glob(os.path.join(run_dir, "out", "*", "monitors", "file", "traces", "stream", "*.jsonl.zst"))):
        for line in pyzstd.decompress(open(f, "rb").read()).decode().splitlines():
            if line.strip():
                ep = json.loads(line)
                for t in ep.get("traces", []):
                    out.append((ep, t))
    return out


def save_screens(run, trace, raw):
    """The first and the last screenshot the model saw in this trace, as PNG files under RD/screens/<run>/ (for a person)."""
    env = ((trace.get("info") or {}).get("drums") or {}).get("env") or trace.get("id", "x")[:8]
    d = os.path.join(RD, "screens", run)
    os.makedirs(d, exist_ok=True)
    for tag, b in (("first", raw[0]), ("last", raw[-1])) if raw else ():
        open(os.path.join(d, f"{env}-{tag}.png"), "wb").write(b)


def images(trace, raw=None):
    """(role, sha256, bytes) of every image the model was given, in order."""
    out = []
    for n in trace.get("nodes", []):
        m = n.get("message") or {}
        c = m.get("content")
        for p in c if isinstance(c, list) else []:
            url = ((p.get("image_url") or {}).get("url") or "") if isinstance(p, dict) else ""
            if url.startswith("data:image"):
                b = base64.b64decode(url.split(",", 1)[1])
                out.append((m.get("role"), hashlib.sha256(b).hexdigest()[:16], len(b)))
                if raw is not None:
                    raw.append(b)
    return out


def run_summary(name):
    d = os.path.join(RD, "runs", name)
    rec = [json.loads(l) for l in open(os.path.join(d, "record.jsonl"))] if os.path.exists(os.path.join(d, "record.jsonl")) else []
    cleanup_failed = [r for r in rec if r.get("cleanup_failed")]
    rec = [r for r in rec if not r.get("cleanup_failed")]
    tr = traces_of(d) if os.path.isdir(os.path.join(d, "out")) else []
    shots = []
    executed = {r.get("env"): r.get("actions") for r in rec}
    for ep, t in tr:
        raw = []
        im = images(t, raw)
        save_screens(name, t, raw)
        # count distinct tool calls and the distinct ones whose result carried a screenshot: with the image window the
        # trace stores each trimmed request as its own branch, so the same call appears in several nodes
        call_ids = {c.get("id") for n in t.get("nodes", []) for c in ((n.get("message") or {}).get("tool_calls") or [])}
        shot_ids = {(n.get("message") or {}).get("tool_call_id") for n in t.get("nodes", [])
                    if (n.get("message") or {}).get("role") == "tool" and isinstance((n.get("message") or {}).get("content"), list)
                    and any(isinstance(p, dict) and p.get("type") == "image_url" for p in n["message"]["content"])}
        # Every tool call must have its result with a screenshot. The one exception is the response stopped by the
        # adapter's `turn_cap` hook, whose tool calls are refused before the harness runs them (verified against the
        # actions drumsd ran: `actions_executed` below must equal the screenshots recorded). A `max_turns` stop is NOT
        # exempt: there the harness has already run the last call, and its result never reached the trace.
        answered = {(n.get("message") or {}).get("tool_call_id") for n in t.get("nodes", []) if (n.get("message") or {}).get("role") == "tool"}
        if t.get("stop_condition") == "turn_cap":
            call_ids &= answered
        tool_calls = len(call_ids)
        usage = [((c.get("usage") or {}).get("prompt_tokens") or 0) for c in t.get("calls", [])]
        shots.append({"actions_executed": executed.get(((t.get("info") or {}).get("drums") or {}).get("env")),
                      "stop": t.get("stop_condition"), "max_prompt_tokens_server": max(usage, default=0), "model_calls": len(usage),
                      "finish_reasons": dict(collections.Counter(c.get("finish_reason") for c in t.get("calls", []))),
                      "env": (t.get("info") or {}).get("drums", {}).get("env"), "first_user_image": bool(im and im[0][0] == "user"),
                      "tool_images": len(call_ids & shot_ids), "tool_calls": tool_calls,
                      "distinct_images": len({h for _, h, _ in im}), "ok": t.get("ok"), "dropped": t.get("dropped")})
    eps = episodes_of(d) if os.path.isdir(os.path.join(d, "out")) else []
    s = {"traces_recorded": len(rec), "traces_in_prime_rl_stream": len(tr),
         "episodes_in_prime_rl_stream": len(eps), "episodes_with_no_trace": sum(1 for e in eps if e["traces"] == 0),
         "episode_errors": dict(collections.Counter(e["error"] for e in eps if e["ok"] is False and e["error"])),
         "episodes_failed_recorded": sum(1 for r in rec if r.get("episode_failed") or r.get("env_create_failed")),
         "admission_waits": sum(len(r.get("admission_waits") or []) for r in rec),
         "cleanup_failed": [r.get("cleanup_failed") + ": " + (r.get("error") or "")[:120] for r in cleanup_failed],
         "valid_rewarded": sum(1 for r in rec if r.get("valid") and r.get("reward") is not None),
         "dropped": sum(1 for r in rec if r.get("dropped")), "errored": sum(1 for r in rec if r.get("ok") is False),
         "fork_children_failed": sum(1 for r in rec if r.get("fork_child_failed")),
         "reward_on_invalid": sum(1 for r in rec if r.get("valid") is False and r.get("reward") is not None),
         "rewards": dict(collections.Counter(str(r.get("reward")) for r in rec if not r.get("fork_child_failed"))),
         "drop_reasons": dict(collections.Counter(r["dropped"] for r in rec if r.get("dropped"))),
         "errors": dict(collections.Counter((r.get("errors") or ["?"])[0][:160] for r in rec if r.get("ok") is False)),
         "by_task": {}, "screenshots": shots,
         "max_prompt_tokens_server": max((x["max_prompt_tokens_server"] for x in shots), default=0)}
    for r in rec:
        k = s["by_task"].setdefault((r.get("task") or "?")[:8], {"n": 0, "reward_sum": 0.0, "valid": 0})
        k["n"] += 1
        k["valid"] += bool(r.get("valid"))
        k["reward_sum"] += r.get("reward") or 0.0
    parents = collections.defaultdict(set)
    for r in rec:
        if r.get("parent"):
            parents[r["parent"]].add(r.get("env"))
    s["fork_groups"] = {p: len(c) for p, c in parents.items()}
    for f in glob.glob(os.path.join(d, "out", "*", "monitors", "file", "metrics.jsonl")):
        last = {}
        for line in open(f):
            last.update(json.loads(line))
        s["prime_rl_metrics"] = {k: v for k, v in last.items() if any(x in k for x in ("reward/mean", "dropped", "has_error/mean", "drums_valid/mean", "pass@"))}
    return s


runs = {os.path.basename(p): run_summary(os.path.basename(p)) for p in sorted(glob.glob(os.path.join(RD, "runs", "*")))}
checks = {}
for name, s in runs.items():
    n = s["traces_recorded"]
    checks[f"{name}: traces recorded"] = n > 0
    checks[f"{name}: no reward on an invalid episode"] = s["reward_on_invalid"] == 0
    checks[f"{name}: every trace valid+rewarded, dropped, or errored"] = s["valid_rewarded"] + s["dropped"] + s["errored"] + s["fork_children_failed"] == n
    checks[f"{name}: every episode prime-rl recorded without a trace has the adapter's failed-episode row"] = \
        s["episodes_with_no_trace"] == s["episodes_failed_recorded"]
    checks[f"{name}: every env and fork state was closed (no cleanup failed)"] = not s["cleanup_failed"]
    checks[f"{name}: every trace saw a first screenshot"] = all(x["first_user_image"] for x in s["screenshots"]) and bool(s["screenshots"])
    checks[f"{name}: a screenshot answered every tool call"] = all(x["tool_images"] >= x["tool_calls"] for x in s["screenshots"] if x["ok"] and not x["dropped"])
    checks[f"{name}: every action drumsd ran has its screenshot in the trace"] = all(
        x["actions_executed"] is None or x["tool_images"] >= x["actions_executed"] for x in s["screenshots"] if x["ok"] and not x["dropped"])
if "B-fork" in runs:
    checks["B-fork: children are distinct envs grouped under one parent each"] = bool(runs["B-fork"]["fork_groups"]) and all(v >= 1 for v in runs["B-fork"]["fork_groups"].values())
if "C-control" in runs:
    c = runs["C-control"]
    checks["C-control: every child dropped as drums_invalid (alive gate), none rewarded"] = c["traces_recorded"] > 0 and c["dropped"] == c["traces_recorded"] and all(k.startswith("drums_invalid") for k in c["drop_reasons"])
phases = [json.loads(l) for l in open(os.path.join(RD, "phases.jsonl"))] if os.path.exists(os.path.join(RD, "phases.jsonl")) else []
cut = [p["phase"] for p in phases if p["phase"].startswith("run-") and p.get("rc") == 124]
verdict = {"pass": all(checks.values()) and not cut, "partial_at_deadline": cut, "checks": checks}
out = {"verdict": verdict, "runs": runs}
if os.path.exists(os.path.join(RD, "settings.json")):
    out["settings"] = json.load(open(os.path.join(RD, "settings.json")))
mock = os.path.join(RD, "mock_calls.jsonl")
if os.path.exists(mock):
    rows = [json.loads(l) for l in open(mock)]
    out["prompt_window"] = {"requests": len(rows), "max_images": max((r.get("images", 0) for r in rows), default=0),
                            "max_prompt_tokens_est": max((r.get("prompt_tokens_est", 0) for r in rows), default=0)}
for f in ("versions.txt", "phases.jsonl", "host.txt"):
    p = os.path.join(RD, f)
    if os.path.exists(p):
        out[f] = open(p).read()
json.dump(out, open(os.path.join(RD, "summary.json"), "w"), indent=1, default=str)
print(json.dumps({**verdict, "settings": out.get("settings"), "prompt_window": out.get("prompt_window")}, indent=1))
for name, s in runs.items():
    print(name, {k: s[k] for k in ("episodes_in_prime_rl_stream", "episodes_with_no_trace", "traces_recorded", "valid_rewarded", "dropped",
                                   "errored", "admission_waits", "rewards", "drop_reasons", "fork_groups")})
